#include "aw_decision/bt_executor.hpp"

int main(int argc, char **argv)
{
    setlocale(LC_ALL, "");
    rclcpp::init(argc, argv);
    rclcpp::NodeOptions options;
    auto bte = std::make_shared<aw_decision::BTExecutor>(options);
    bte->init();

    rclcpp::executors::MultiThreadedExecutor executor(
        rclcpp::ExecutorOptions(), 0, false, std::chrono::milliseconds(1000));
    executor.add_node(bte);
    executor.spin();
    executor.remove_node(bte);

    rclcpp::shutdown();
}