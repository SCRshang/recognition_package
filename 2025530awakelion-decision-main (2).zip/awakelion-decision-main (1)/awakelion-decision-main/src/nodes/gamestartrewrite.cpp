#include "aw_decision/nodes/gamestart.hpp"

namespace aw_decision
{
    GameStart::GameStart(const std::string &name, const BT::NodeConfiguration &config)
        : BT::SimpleConditionNode(name, std::bind(&GameStart::isGameStart, this), config)
    {
    }

    BT::PortsList GameStart::providedPorts()
    {
        return {BT::InputPort<bool>("gamestart", "{@gamestart}", "Game start status port")};
    }

    BT::NodeStatus GameStart::isGameStart()
    {
        auto gamestart = getInput<bool>("gamestart");
        if (!gamestart)
        {
            std::cerr << "GameStart: Failed to get port of gamestart!" << std::endl;
            return BT::NodeStatus::FAILURE;
        }

        if (gamestart.value())
        {
            std::cout << "GameStart: Game start!" << std::endl;
            return BT::NodeStatus::SUCCESS;
        }
        else
        {
            std::cout << "GameStart: wait for Game start..." << std::endl;
            return BT::NodeStatus::FAILURE;
        }
    }
} // namespace aw_decision