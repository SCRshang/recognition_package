# awakelion-decision
awakelion decision based on BehaviorTree.CPP.

## Nodes Hierarchy
```
nodes
├── DetectArmor
├── GameStart
├── GOTO
├── JudgeStatus
├── patrol
├── Relocalization
└── Track
```