#ifndef NODES__GAMESTART_HPP
#define NODES__GAMESTART_HPP

#include <behaviortree_cpp/condition_node.h>

#include "aw_decision/msg_type.hpp"

namespace aw_decision
{
    /***
     * @brief inherited class: `BT::SimpleConditionNode` to judge game start status
     */
    class GameStart : public BT::SimpleConditionNode
    {   
    public:
        GameStart(const std::string &name, const BT::NodeConfiguration &config);

        static BT::PortsList providedPorts();

    private:
        /***
         * @brief callback function to check if game has started
         */
        BT::NodeStatus isGameStart();
    };
} // namespace aw_decision

#endif //! NODES__GAMESTART_HPP