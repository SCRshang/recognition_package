#ifndef POSITION_2D_TYPE_HPP
#define POSITION_2D_TYPE_HPP

#include <rclcpp/rclcpp.hpp>
#include <behaviortree_cpp/basic_types.h>

/***
 * @brief Position2D as a simple type to store 2D point
 * @param x position x
 * @param y position y
 * @param yaw yaw angle [radian]
 */
struct Position2D
{
    double x;   // position x
    double y;   // position y
    double yaw; // yaw angle [radian]
};

namespace BT
{
    /***
     * @brief Convert string to Position2D type
     * @note reference: https://www.behaviortree.dev/docs/tutorial-basics/tutorial_03_generic_ports
     */
    template <>
    inline Position2D convertFromString(StringView str)
    {
        // We expect real numbers separated by semicolons
        auto parts = BT::splitString(str, ';');
        if (parts.size() != 3)
        {
            throw RuntimeError("Invalid input! Type is Position2D[x, y, yaw].");
        }
        else
        {
            Position2D output;
            output.x = convertFromString<double>(parts[0]);
            output.y = convertFromString<double>(parts[1]);
            output.yaw = convertFromString<double>(parts[2]);
            return output;
        }
    }
} // namespace BT

#endif //! POSITION_2D_TYPE_HPP