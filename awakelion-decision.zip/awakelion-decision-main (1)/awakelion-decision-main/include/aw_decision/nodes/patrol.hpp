#ifndef NODES__PATROL_HPP
#define NODES__PATROL_HPP

#include <rclcpp/rclcpp.hpp>
#include <rclcpp_action/rclcpp_action.hpp>
#include <nav_msgs/msg/path.hpp>
#include <nav2_msgs/action/follow_path.hpp>

#include <behaviortree_cpp/action_node.h>

#include "aw_decision/position_2d_type.hpp"

namespace aw_decision
{
    /***
     * @brief inherited class: `BT::StatefulActionNode` to patrol
     */
    class Patrol : public BT::StatefulActionNode
    {
    public:
        /***
         * @brief local planner action to follow path
         */
        using LocalPlannerAction = nav2_msgs::action::FollowPath;

        /***
         * @brief local planner goal handler typedef
         */
        using LocalPlannerGoalHandler = rclcpp_action::ClientGoalHandle<LocalPlannerAction>;

        /***
         * @brief local planner action client typedef
         */
        using LocalPlannerClient = rclcpp_action::Client<LocalPlannerAction>;

        Patrol(const std::string &name, const BT::NodeConfiguration &config);

        BT::NodeStatus onStart() override;

        BT::NodeStatus onRunning() override;

        void onHalted() override;

        static BT::PortsList providedPorts();

    private:
        /***
         * @brief node for rclcpp
         */
        rclcpp::Node::SharedPtr node_;

        /***
         * @brief local planner goal handler
         */
        LocalPlannerGoalHandler::SharedPtr local_planner_goal_handler_;

        /***
         * @brief local planner action client
         */
        LocalPlannerClient::SharedPtr local_planner_client_;

        /***
         * @brief publisher of computed path
         * @note ONLY for `debug_en`: true
         */
        rclcpp::Publisher<nav_msgs::msg::Path>::SharedPtr path_pub_;

        /***
         * @brief start patrol 2d point
         */
        BT::Expected<Position2D> start_point_;

        /***
         * @brief end patrol 2d point
         */
        BT::Expected<Position2D> end_point_;

        /***
         * @brief maximum constraint point
         */
        BT::Expected<Position2D> max_point_;

        /***
         * @brief minimum constraint point
         */
        BT::Expected<Position2D> min_point_;

        /***
         * @brief the number of patrol path points
         */
        BT::Expected<int> path_point_num_;

        /***
         * @brief patrol mode
         * @note `"cubic_bezier"`: compute path as cubic bezier curve
         * @note `"circle"`: compute path as circle
         * @note `"square"`: compute path as square
         */
        BT::Expected<std::string> patrol_mode_;

        /***
         * @brief halt time to scan enemies
         */
        BT::Expected<double> halt_time_;

        /***
         * @brief patrol path points
         */
        std::vector<Position2D> path_points_;

        /***
         * @brief std::promise to set node status
         */
        std::shared_ptr<std::promise<BT::NodeStatus>> status_promise_;

        /***
         * @brief std::future to get node status
         */
        std::future<BT::NodeStatus> status_future_;

        /***
         * @brief flag whether path sent
         */
        bool is_path_sent_;

        /***
         * @brief flag whether the path forward from `start_point` to `end_point`
         */
        bool is_forward_;

        /***
         * @brief flag whether robot is halted or not
         */
        bool is_halted_;

        /***
         * @brief compute path as cubic bezier curve
         * @param start_pt start point
         * @param end_pt end point
         * @param path_point_num the number of patrol path points
         * @return path points
         */
        std::vector<Position2D> computeCubicBezierPath(const Position2D &start_pt,
                                                       const Position2D &end_pt,
                                                       const int &path_point_num);

        /***
         * @brief compute path as circle
         * @param start_pt start point
         * @param end_pt end point
         * @param path_point_num the number of patrol path points
         * @return path points
         */
        std::vector<Position2D> computeCirclePath(const Position2D &start_pt,
                                                  const Position2D &end_pt,
                                                  const int &path_point_num);

        /***
         * @brief compute path as square
         * @param start_pt start point
         * @param end_pt end point
         * @return path points
         */
        std::vector<Position2D> computeSquarePath(const Position2D &start_pt,
                                                  const Position2D &end_pt);

        /***
         * @brief send path[]
         * @param path_pts path points
         */
        void sendPath(const std::vector<Position2D> &path_pts);

        /***
         * @brief verify path points whether in range of `[min_x, max_x]` and `[min_y, max_y]`
         * @param path_pts path points
         */
        void verifyPathPoints(const std::vector<Position2D> &path_pts);
    };
} // namespace aw_decision

#endif //! NODES__PATROL_HPP