#ifndef NODES__RELOCALIZATION_HPP
#define NODES__RELOCALIZATION_HPP

#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/point_cloud2.hpp>

#include <behaviortree_cpp/action_node.h>

#include "aw_algorithm_utils/estimator/kiss_matcher_registration.hpp"

namespace aw_decision
{
    /***
     * @brief inherited class: `BT::StatefulActionNode` to relocalization
     */
    class Relocalization : public BT::StatefulActionNode
    {
    public:
        Relocalization(const std::string &name, const BT::NodeConfiguration &config);

        BT::NodeStatus onStart() override;

        BT::NodeStatus onRunning() override;

        void onHalted() override;

        static BT::PortsList providedPorts();

    private:
        /***
         * @brief node for rclcpp
         */
        rclcpp::Node::SharedPtr node_;

        /***
         * @brief kiss matcher registration
         */
        aw_algorithm_utils::estimator::KissMatcherRegistration kiss_matcher_;

        /***
         * @brief relocalization timeout
         */
        BT::Expected<int> relocalization_timeout_;

        /***
         * @brief target pointcloud
         */
        pcl::PointCloud<pcl::PointXYZ>::Ptr pcl_target_;

        /***
         * @brief flag whether finish relocalization
         */
        bool is_finish_relocalization_;
    };
}

#endif //! NODES__RELOCALIZATION_HPP
