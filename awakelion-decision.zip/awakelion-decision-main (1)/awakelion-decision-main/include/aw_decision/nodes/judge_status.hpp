#ifndef NODES__JUDGE_STATUS_HPP
#define NODES__JUDGE_STATUS_HPP

#include <rclcpp/rclcpp.hpp>

#include <behaviortree_cpp/condition_node.h>

#include "aw_decision/msg_type.hpp"

namespace aw_decision
{
    /***
     * @brief  inherited class: `BT::SimpleConditionNode` to judge specified status
     */
    class JudgeStatus : public BT::SimpleConditionNode
    {
    public:
        JudgeStatus(const std::string &name, const BT::NodeConfiguration &config);

        static BT::PortsList providedPorts();

    private:
        /***
         * @brief rmuc common message
         */
        BT::Expected<bt_interfaces::msg::Common> rmuc_common_msg_;

        /***
         * @brief rmuc robot status message
         */
        BT::Expected<bt_interfaces::msg::RobotStatus> rmuc_robot_status_msg_;

        /***
         * @brief threshold value
         */
        BT::Expected<int> threshold_;

        /***
         * @brief judge type
         * @note `"HP"`: judge sentry hp
         * @note `"OUTPOST_HP"`: judge outpost hp
         * @note `"BASE_HP"`: judge base hp
         * @note `"AMMO"`: judge ammo
         * @note `"TIME"`: judge time
         */
        BT::Expected<std::string> judge_type_;

        /***
         * @brief threshold mode
         * @note `"MIN"`: threshold is minimum, if threshold is bigger(equal include), return true, or return false
         * @note `"MAX"`: threshold is maximum, if threshold is smaller(equal not include), return true, or return false
         */
        BT::Expected<std::string> threshold_mode_;

        /***
         * @brief current value to be judged
         */
        int current_val_;

        /***
         * @brief callback function to judge specified status
         */
        BT::NodeStatus judgeStatus();
    };
} // namespace aw_decision

#endif //! NODES__JUDGE_STATUS_HPP