#ifndef NODES__GOTO_HPP
#define NODES__GOTO_HPP

#include <rclcpp/rclcpp.hpp>
#include <rclcpp_action/rclcpp_action.hpp>
#include <geometry_msgs//pose_stamped.hpp>
#include <nav2_msgs/action/navigate_to_pose.hpp>

#include <behaviortree_cpp/action_node.h>

#include "aw_decision/position_2d_type.hpp"

namespace aw_decision
{
    /***
     * @brief inherited class: `BT::StatefulActionNode` to navigate specified 2d position
     */
    class GOTO : public BT::StatefulActionNode
    {
    public:
        /***
         * @brief NavigateToPose action to navigate to the goal point
         */
        using NavigateToPose = nav2_s::action::NavigateToPose;

        /***
         * @brief nav goal handler typedef
         */
        using NavGoalHandler = rclcpp_action::ClientGoalHandle<NavigateToPose>;

        /***
         * @brief nav goal client typedef
         */
        using NavClient = rclcpp_action::Client<NavigateToPose>;

        GOTO(const std::string &name, const BT::NodeConfiguration &config);

        BT::NodeStatus onStart() override;

        BT::NodeStatus onRunning() override;

        void onHalted() override;

        static BT::PortsList providedPorts();

    private:
        /***
         * @brief node for rclcpp
         */
        rclcpp::Node::SharedPtr node_;

        /***
         * @brief nav goal action client
         */
        NavClient::SharedPtr nav_client_;

        /***
         * @brief 2d goal point
         */
        BT::Expected<Position2D> goal_2d_;

        /***
         * @brief nav goal status promise to set status
         */
        std::shared_ptr<std::promise<BT::NodeStatus>> status_promise_;

        /***
         * @brief nav goal status future to get status
         */
        std::future<BT::NodeStatus> status_future_;

        /***
         * @brief flag whether goal is sent
         */
        bool is_goal_sent_;
    };
} // namespace aw_decision

#endif //! NODES__GOTO_HPP