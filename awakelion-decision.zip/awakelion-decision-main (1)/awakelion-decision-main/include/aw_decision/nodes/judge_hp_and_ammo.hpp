#ifndef NODES__JUDGE_HP_AND_AMMO_HPP
#define NODES__JUDGE_HP_AND_AMMO_HPP

#include <rclcpp/rclcpp.hpp>

#include <behaviortree_cpp/condition_node.h>

#include "aw_decision/msg_type.hpp"

namespace aw_decision
{
    /***
     * @brief  inherited class: `BT::SimpleConditionNode` to judge hp and ammo
     */
    class JudgeHPandAmmo : public BT::SimpleConditionNode
    {
    public:
        JudgeHPandAmmo(const std::string &name, const BT::NodeConfiguration &config);

        static BT::PortsList providedPorts();

    private:
        /***
         * @brief rmuc common message
         */
        BT::Expected<bt_interfaces::msg::Common> rmuc_common_msg_;

        /***
         * @brief rmuc robot status message
         */
        BT::Expected<bt_interfaces::msg::RobotStatus> rmuc_robot_status_msg_;

        /***
         * @brief hp threshold value
         */
        BT::Expected<int> hp_threshold_;

        /***
         * @brief time threshold value
         */
        BT::Expected<int> time_threshold_;

        /***
         * @brief callback function to judge hp and ammo
         */
        BT::NodeStatus judgeHPandAmmo();
    };
} // namespace aw_decision

#endif //! NODES__JUDGE_HP_AND_AMMO_HPP