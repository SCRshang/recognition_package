#ifndef NODES__DETECT_ARMOR_HPP
#define NODES__DETECT_ARMOR_HPP

#include <behaviortree_cpp/condition_node.h>

#include "auto_aim_interfaces/msg/final_armor.hpp"

namespace aw_decision
{
    class DetectArmor : public BT::ConditionNode
    {
    public:
        DetectArmor(const std::string &name, const BT::NodeConfiguration &config);

        static BT::PortsList providedPorts();

    private:
        /***
         * @brief enemy robot id via its armor
         */
        BT::Expected<int> armor_id_;

        /***
         * @brief current specified armor x
         */
        BT::Expected<double> current_armor_x_;

        /***
         * @brief current specified armor y
         */
        BT::Expected<double> current_armor_y_;

        /***
         * @brief flag whether to track the enemy
         * @note output flag
         */
        BT::Expected<bool> is_track_;

        /***
         * @brief last detected armor id
         */
        int last_armor_id_;

        /***
         * @brief last specified armor x
         */
        double last_armor_x_;

        /***
         * @brief last specified armor y
         */
        double last_armor_y_;
    };
} // namespace aw_decision

#endif //! NODES__DETECT_ARMOR_HPP