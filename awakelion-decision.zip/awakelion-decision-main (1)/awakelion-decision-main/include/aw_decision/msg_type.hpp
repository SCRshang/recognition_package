// head-only to store message type

#ifndef MSG_TYPE_HPP
#define MSG_TYPE_HPP

#include "bt_interfaces/msg/common.hpp"
#include "bt_interfaces/msg/robot_status.hpp"

#endif //! MSG_TYPE_HPP