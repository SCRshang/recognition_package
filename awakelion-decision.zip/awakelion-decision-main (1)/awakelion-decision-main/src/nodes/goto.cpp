#include <tf2/LinearMath/Quaternion.hpp>
#include <geometry_msgs/msg/quaternion.hpp>
#include <tf2_geometry_msgs/tf2_geometry_msgs.hpp>

#include "aw_decision/nodes/goto.hpp"

namespace aw_decision
{
    GOTO::GOTO(const std::string &name, const BT::NodeConfiguration &config)
        : BT::StatefulActionNode(name, config)
    {
        node_ = std::make_shared<rclcpp::Node>("goto_node");
        nav_client_ = rclcpp_action::create_client<NavigateToPose>(node_, "navigate_to_pose");
        if (!nav_client_->wait_for_action_server(std::chrono::seconds(3)))
        {
            RCLCPP_ERROR(node_->get_logger(), "GOTO: Action server is not available after waiting 3s...");
            return;
        }
    }

    BT::PortsList GOTO::providedPorts()
    {
        return {BT::InputPort<Position2D>("goal_2d", "{=}", "2d goal point of this send goal action")};
    }

    BT::NodeStatus GOTO::onStart()
    {
        goal_2d_ = getInput<Position2D>("goal_2d");
        if (!goal_2d_)
        {
            RCLCPP_ERROR(node_->get_logger(), "GOTO: Failed to get port of goal_2d!");
            return BT::NodeStatus::FAILURE;
        }

        /* set goal point */
        auto goal_msg = NavigateToPose::Goal();
        tf2::Quaternion tf_quat;
        tf_quat.setRPY(0, 0, goal_2d_->yaw);
        geometry_msgs::msg::Quaternion quat = tf2::toMsg(tf_quat);

        goal_msg.pose.header.frame_id = "map";
        goal_msg.pose.header.stamp = node_->now();
        goal_msg.pose.pose.position.x = goal_2d_->x;
        goal_msg.pose.pose.position.y = goal_2d_->y;
        goal_msg.pose.pose.position.z = 0.0;
        goal_msg.pose.pose.orientation = quat;

        /* process client options by std::promise */
        auto nav_goal_options = NavClient::SendGoalOptions();
        status_promise_ = std::make_shared<std::promise<BT::NodeStatus>>();
        status_future_ = status_promise_->get_future();
        is_goal_sent_ = false;

        /* goal response callback */
        nav_goal_options.goal_response_callback = [this](auto future)
        {
            if (!future.get())
            {
                RCLCPP_INFO(this->node_->get_logger(), "GOTO: goal rejected...");
                // DO NOT return BT::NodeStatus::FAILURE directly cause if it's rejected
                // it will return a nullptr
                status_promise_->set_value(BT::NodeStatus::FAILURE);
                return;
            }
            RCLCPP_INFO(this->node_->get_logger(), "GOTO: goal accepted!");
            is_goal_sent_ = true;
        };

        /* result callback */
        nav_goal_options.result_callback = [this](const NavGoalHandler::WrappedResult &result)
        {
            status_promise_->set_value(result.code == rclcpp_action::ResultCode::SUCCEEDED
                                           ? BT::NodeStatus::SUCCESS
                                           : BT::NodeStatus::FAILURE);
        };

        /* send goal */
        nav_client_->async_send_goal(goal_msg, nav_goal_options);
        return BT::NodeStatus::RUNNING;
    }

    BT::NodeStatus GOTO::onRunning()
    {
        try
        {
            const auto execute_timeout = std::chrono::seconds(24);
            if (rclcpp::spin_until_future_complete(node_, status_future_, execute_timeout) != rclcpp::FutureReturnCode::SUCCESS)
            {
                RCLCPP_WARN(this->node_->get_logger(), "GOTO: Navigation timeout after 24s...retry send goal");
                nav_client_->async_cancel_all_goals();
                return BT::NodeStatus::FAILURE;
            }
            // return final status, it should be BT::NodeStatus::SUCCESS
            return status_future_.get();
        }
        catch (const rclcpp_action::exceptions::UnknownGoalHandleError &ex)
        {
            RCLCPP_WARN(this->node_->get_logger(), "GOTO: fail to navigate: %s", ex.what());
            return BT::NodeStatus::FAILURE;
        }
    }

    void GOTO::onHalted()
    {
        if (nav_client_)
            nav_client_->async_cancel_all_goals();
    }
} // namespace aw_decision
