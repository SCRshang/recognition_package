#include "aw_decision/nodes/gamestart.hpp"

namespace aw_decision
{
    GameStart::GameStart(const std::string &name, const BT::NodeConfiguration &config)
        : BT::SimpleConditionNode(name, std::bind(&GameStart::isGameStart, this), config)
    {
    }

    BT::PortsList GameStart::providedPorts()
    {
        return {BT::InputPort<bt_interfaces::msg::Common>("rmuc_common_msg", "{@rmuc_common_msg}", "rmuc_common message type port")};
    }

    BT::NodeStatus GameStart::isGameStart()
    {
        rmuc_common_msg_ = getInput<bt_interfaces::msg::Common>("rmuc_common_msg");
        if (!rmuc_common_msg_)
        {
            std::cerr << "GameStart: Failed to get port of rmuc_common_msg!" << std::endl;
            return BT::NodeStatus::FAILURE;
        }

        if (static_cast<bool>(rmuc_common_msg_->gamestart))
        {
            std::cout << "GameStart: Game start!" << std::endl;
            return BT::NodeStatus::SUCCESS;
        }
        else
        {
            std::cout << "GameStart: wait for Game start..." << std::endl;
            return BT::NodeStatus::FAILURE;
        }
    }
} // namespace aw_decision