#include <limits>

#include "aw_decision/nodes/judge_status.hpp"

namespace aw_decision
{
    JudgeStatus::JudgeStatus(const std::string &name, const BT::NodeConfiguration &config)
        : BT::SimpleConditionNode(name, std::bind(&JudgeStatus::judgeStatus, this), config),
          current_val_(std::numeric_limits<int>::min())
    {
    }

    BT::PortsList JudgeStatus::providedPorts()
    {
        return {BT::InputPort<bt_interfaces::msg::Common>("rmuc_common_msg", "{@rmuc_common_msg}", "rmuc_common message type port"),
                BT::InputPort<bt_interfaces::msg::RobotStatus>("rmuc_robot_status_msg", "{@rmuc_robot_status_msg}", "rmuc_robot_status message type port"),
                BT::InputPort<int>("threshold", "{=}", "threshold value"),
                BT::InputPort<std::string>("judge_type", "{=}", "judge type, include HP, OUTPOST_HP, BASE_HP, AMMO and TIME"),
                BT::InputPort<std::string>("threshold_mode", "{=}", "threshold mode include MIN and MAX")};
    }

    BT::NodeStatus JudgeStatus::judgeStatus()
    {
        bool all_valid = true;
        rmuc_common_msg_ = getInput<bt_interfaces::msg::Common>("rmuc_common_msg");
        rmuc_robot_status_msg_ = getInput<bt_interfaces::msg::RobotStatus>("rmuc_robot_status_msg");
        threshold_ = getInput<int>("threshold");
        judge_type_ = getInput<std::string>("judge_type");
        threshold_mode_ = getInput<std::string>("threshold_mode");
        if (!rmuc_common_msg_)
        {
            std::cerr << "JudgeStatus: Failed to get port of rmuc_common_msg!" << std::endl;
            all_valid = false;
        }
        if (!rmuc_robot_status_msg_)
        {
            std::cerr << "JudgeStatus: Failed to get port of rmuc_robot_status_msg!" << std::endl;
            all_valid = false;
        }
        if (!threshold_)
        {
            std::cerr << "JudgeStatus: Failed to get port of threshold!" << std::endl;
            all_valid = false;
        }
        if (!judge_type_)
        {
            std::cerr << "JudgeStatus: Failed to get port of judge_type!" << std::endl;
            all_valid = false;
        }
        if (!threshold_mode_)
        {
            std::cerr << "JudgeStatus: Failed to get port of threshold_mode!" << std::endl;
            all_valid = false;
        }
        if (!all_valid)
            return BT::NodeStatus::FAILURE;

        const auto &threshold_val = threshold_.value();
        const auto &judge_type_val = judge_type_.value();
        const auto &threshold_mode_val = threshold_mode_.value();

        if (judge_type_val == "HP")
        {
            current_val_ = rmuc_robot_status_msg_->current_hp;
        }
        else if (judge_type_val == "OUTPOST_HP")
        {
            current_val_ = rmuc_robot_status_msg_->we_outpost_hp;
        }
        else if (judge_type_val == "BASE_HP")
        {
            current_val_ = rmuc_robot_status_msg_->we_base_hp;
        }
        else if (judge_type_val == "AMMO")
        {
            current_val_ = rmuc_robot_status_msg_->current_ammo;
        }
        else if (judge_type_val == "TIME")
        {
            current_val_ = 420 - rmuc_common_msg_->stage_remain_time;
        }
        else
        {
            std::cerr << "Invalid judge type!" << std::endl;
            return BT::NodeStatus::FAILURE;
        }

        std::cout << "judge type: " << judge_type_val
                  << "current value: " << current_val_ << std::endl;

        if (threshold_mode_val == "MIN")
            return (current_val_ >= threshold_val) ? BT::NodeStatus::SUCCESS : BT::NodeStatus::FAILURE;
        else if (threshold_mode_val == "MAX")
            return (current_val_ < threshold_val) ? BT::NodeStatus::SUCCESS : BT::NodeStatus::FAILURE;
        else
        {
            std::cerr << "Invalid threshold mode!" << std::endl;
            return BT::NodeStatus::FAILURE;
        }
    }
} // namespace aw_decision