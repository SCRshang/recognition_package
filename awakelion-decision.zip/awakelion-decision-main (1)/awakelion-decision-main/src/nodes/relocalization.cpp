#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>
#include <pcl/point_cloud.h>

#include "aw_decision/nodes/relocalization.hpp"

namespace aw_decision
{
    Relocalization::Relocalization(const std::string &name, const BT::NodeConfiguration &config)
        : BT::StatefulActionNode(name, config),
          kiss_matcher_("aw_decision/relocalization_node", rclcpp::NodeOptions())
    {
        const std::string pcd_file_path = "const pcd file path";
        if (pcl::io::loadPCDFile<pcl::PointXYZ>(pcd_file_path, *pcl_target_) == -1)
        {
            std::cerr << "Couldn't read pcd file: " << pcd_file_path.c_str() << std::endl;
            return;
        }
    }

    BT::PortsList Relocalization::providedPorts()
    {
        return {BT::InputPort<std::string>("relocalization_timeout", "{=}", "relocalization timeout")};
    }

    BT::NodeStatus Relocalization::onStart()
    {
        // TODO: add service client to request initial registration to stop
        return BT::NodeStatus::RUNNING;
    }

    BT::NodeStatus Relocalization::onRunning()
    {
        return BT::NodeStatus::SUCCESS;
    }

    void Relocalization::onHalted()
    {
        // TODO: stop the service client
    }

} // namespace aw_decision
