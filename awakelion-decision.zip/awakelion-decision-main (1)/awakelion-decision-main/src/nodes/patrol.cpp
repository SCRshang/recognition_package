#include <random>

#include <tf2/LinearMath/Quaternion.hpp>
#include <tf2_geometry_msgs/tf2_geometry_msgs.hpp>

#include "aw_decision/nodes/patrol.hpp"

#define PATROL_PATH_VISUALIZATION

namespace aw_decision
{
    Patrol::Patrol(const std::string &name, const BT::NodeConfiguration &config)
        : BT::StatefulActionNode(name, config)
    {
        node_ = std::make_shared<rclcpp::Node>("patrol_node");
        local_planner_client_ = rclcpp_action::create_client<LocalPlannerAction>(node_, "follow_path");
        if (!local_planner_client_->wait_for_action_server(std::chrono::seconds(3)))
        {
            RCLCPP_ERROR(node_->get_logger(), "Patrol: Action server is not available after waiting 3s...");
            return;
        }
        path_points_.clear();

        /* optional: visualize the path on RVIZ */
#ifdef PATROL_PATH_VISUALIZATION
        RCLCPP_INFO(node_->get_logger(), "Patrol: patrol path visualization is on");
        path_pub_ = node_->create_publisher<nav_msgs::msg::Path>("aw_decision/patrol_path", 10);
#endif
    }

    BT::PortsList Patrol::providedPorts()
    {
        return {BT::InputPort<Position2D>("start_point", "{=}", "patrol start point"),
                BT::InputPort<Position2D>("end_point", "{=}", "patrol end point"),
                BT::InputPort<Position2D>("max_point", "{=}", "maximum constraint point"),
                BT::InputPort<Position2D>("min_point", "{=}", "minimum constraint point"),
                BT::InputPort<int>("path_point_num", "{=}", "the number of patrol path points"),
                BT::InputPort<std::string>("patrol_mode", "{=}", "patrol mode include CUBIC_BEZIER, CIRCLE and SQUARE"),
                BT::InputPort<double>("halt_time", "{=}", "halt time to scan enemies")};
    }

    BT::NodeStatus Patrol::onStart()
    {
        bool all_valid = true;
        start_point_ = getInput<Position2D>("start_point");
        end_point_ = getInput<Position2D>("end_point");
        max_point_ = getInput<Position2D>("max_point");
        min_point_ = getInput<Position2D>("min_point");
        path_point_num_ = getInput<int>("path_point_num");
        patrol_mode_ = getInput<std::string>("patrol_mode");
        halt_time_ = getInput<double>("halt_time");
        if (!start_point_)
        {
            RCLCPP_ERROR(node_->get_logger(), "Patrol: Failed to get port of start_point!");
            all_valid = false;
        }
        if (!end_point_)
        {
            RCLCPP_ERROR(node_->get_logger(), "Patrol: Failed to get port of end_point!");
            all_valid = false;
        }
        if (!path_point_num_)
        {
            RCLCPP_ERROR(node_->get_logger(), "Patrol: Failed to get port of path_point_num!");
            all_valid = false;
        }
        if (!patrol_mode_)
        {
            RCLCPP_ERROR(node_->get_logger(), "Patrol: Failed to get port of patrol_mode!");
            all_valid = false;
        }
        if (!halt_time_)
        {
            RCLCPP_ERROR(node_->get_logger(), "Patrol: Failed to get port of halt_time!");
            all_valid = false;
        }
        const auto &start_point_val = start_point_.value();
        const auto &end_point_val = end_point_.value();
        const auto &path_point_num_val = path_point_num_.value();
        const auto &patrol_mode_val = patrol_mode_.value();
        // const auto &halt_time_val = halt_time_.value();
        if (patrol_mode_val != "SQUARE" && path_point_num_val < 4)
        {
            RCLCPP_ERROR(node_->get_logger(), "Patrol: path_point_num should be greater than 3!");
            all_valid = false;
        }
        if (!all_valid)
            return BT::NodeStatus::FAILURE;

        status_promise_ = std::make_shared<std::promise<BT::NodeStatus>>();
        status_future_ = status_promise_->get_future();

        try
        {
            if (patrol_mode_val == "CUBIC_BEZIER")
                path_points_ = computeCubicBezierPath(start_point_val, end_point_val, path_point_num_val);
            else if (patrol_mode_val == "CIRCLE")
                path_points_ = computeCirclePath(start_point_val, end_point_val, path_point_num_val);
            else if (patrol_mode_val == "SQUARE")
                path_points_ = computeSquarePath(start_point_val, end_point_val);

            verifyPathPoints(path_points_);
        }
        catch (const std::exception &ex)
        {
            RCLCPP_WARN(this->node_->get_logger(), "Patrol: %s", ex.what());
            return BT::NodeStatus::FAILURE;
        }

        return BT::NodeStatus::RUNNING;
    }

    BT::NodeStatus Patrol::onRunning()
    {
        if (!is_path_sent_)
        {
            sendPath(path_points_);
            is_path_sent_ = true;
        }
        return BT::NodeStatus::RUNNING;
    }

    void Patrol::onHalted()
    {
        if (local_planner_client_)
            local_planner_client_->async_cancel_all_goals();
    }

    std::vector<Position2D> Patrol::computeCubicBezierPath(const Position2D &start_pt,
                                                           const Position2D &end_pt,
                                                           const int &path_point_num)
    {
        std::vector<Position2D> control_pts, path_pts;
        std::random_device rd;
        std::mt19937 gen(rd());
        const double range = std::hypot(end_pt.x - start_pt.x, end_pt.y - start_pt.y) * 0.5;
        const double valid_range = std::max(range, 1.0);
        std::uniform_real_distribution<double> x_dist(
            start_pt.x - valid_range,
            start_pt.x + valid_range);
        std::uniform_real_distribution<double> y_dist(
            start_pt.y - valid_range,
            start_pt.y + valid_range);

        control_pts.reserve(2);
        path_pts.reserve(path_point_num);

        /*
            generate random control points
            NOTE that the number is 2 cause cubic bezier curve has 2 control points
        */
        do
        {
            for (int i = 0; i < 2; ++i)
            {
                control_pts.emplace_back(Position2D{
                    x_dist(gen),
                    y_dist(gen)});
            }
        } while (std::hypot(control_pts[0].x - control_pts[1].x, control_pts[0].y - control_pts[1].y) < 0.3);

        /* generate cubic bezier path points */
        const auto &p0 = start_pt;
        const auto &p1 = control_pts.at(0);
        const auto &p2 = control_pts.at(1);
        const auto &p3 = end_pt;

        Position2D last_pt = start_pt;
        for (int i = 0; i < path_point_num; ++i)
        {
            /* normalized param which represents the CURRENT position of the point */
            const double t = static_cast<double>(i) / static_cast<double>(path_point_num - 1);

            /* calculate the path point via bezier formula */
            double pt_x = std::pow(1 - t, 3) * p0.x +
                          3 * std::pow(1 - t, 2) * t * p1.x +
                          3 * (1 - t) * std::pow(t, 2) * p2.x +
                          std::pow(t, 3) * p3.x;
            double pt_y = std::pow(1 - t, 3) * p0.y +
                          3 * std::pow(1 - t, 2) * t * p1.y +
                          3 * (1 - t) * std::pow(t, 2) * p2.y +
                          std::pow(t, 3) * p3.y;
            double pt_yaw = atan2(pt_y - last_pt.y, pt_x - last_pt.x);
            path_pts.emplace_back(Position2D{pt_x, pt_y, pt_yaw});
            last_pt = Position2D{pt_x, pt_y, pt_yaw};
        }

        return path_pts;
    }

    std::vector<Position2D> Patrol::computeCirclePath(const Position2D &start_pt,
                                                      const Position2D &end_pt,
                                                      const int &path_point_num)
    {
        std::vector<Position2D> path_pts;
        path_pts.reserve(path_point_num);

        const double center_x = (start_pt.x + end_pt.x) / 2.0;
        const double center_y = (start_pt.y + end_pt.y) / 2.0;
        const double diameter = std::hypot(end_pt.x - start_pt.x, end_pt.y - start_pt.y);
        const double radius = diameter / 2.0;

        const double start_angle = atan2(start_pt.y - center_y, start_pt.x - center_x);

        for (int i = 0; i < path_point_num; ++i)
        {
            double theta = start_angle + 2 * M_PI * i / path_point_num;
            const double tan_angle = theta + M_PI_2;
            const double x = center_x + radius * cos(theta);
            const double y = center_y + radius * sin(theta);
            path_pts.emplace_back(Position2D{x, y, tan_angle});
        }

        return path_pts;
    }

    std::vector<Position2D> Patrol::computeSquarePath(const Position2D &start_pt,
                                                      const Position2D &end_pt)
    {
        std::vector<Position2D> path_pts;
        const double dx = end_pt.x - start_pt.x;
        const double dy = end_pt.y - start_pt.y;

        path_pts.emplace_back(start_pt);
        path_pts.emplace_back(Position2D{start_pt.x + dx, start_pt.y, M_PI_2});
        path_pts.emplace_back(Position2D{start_pt.x + dx, start_pt.y + dy, M_PI});
        path_pts.emplace_back(Position2D{start_pt.x, start_pt.y + dy, start_pt.yaw + M_PI + M_PI_2});
        path_pts.emplace_back(start_pt);
        return path_pts;
    }

    void Patrol::sendPath(const std::vector<Position2D> &path_pts)
    {
        /* initialize path message */
        auto goal_msg = LocalPlannerAction::Goal();
        goal_msg.path.header.frame_id = "map";
        goal_msg.path.header.stamp = node_->now();

        /* convert path points to geometry::msg::PoseStamped message */
        for (const auto &pt : path_pts)
        {
            geometry_msgs::msg::PoseStamped pose_stamped;
            pose_stamped.pose.position.x = pt.x;
            pose_stamped.pose.position.y = pt.y;
            pose_stamped.pose.position.z = 0.0;
            tf2::Quaternion quat;
            quat.setRPY(0, 0, pt.yaw);
            pose_stamped.pose.orientation = tf2::toMsg(quat);
            goal_msg.path.poses.emplace_back(std::move(pose_stamped));
        }

        auto local_planner_options_ = LocalPlannerClient::SendGoalOptions();
        /* goal response callback */
        local_planner_options_.goal_response_callback = [this](auto future)
        {
            if (!future.get())
            {
                RCLCPP_INFO(this->node_->get_logger(), "Patrol: goal rejected...");
                /*
                    DO NOT return BT::NodeStatus::FAILURE directly cause if it's rejected
                    it will return a nullptr
                */
                status_promise_->set_value(BT::NodeStatus::FAILURE);
                return;
            }
            RCLCPP_INFO(this->node_->get_logger(), "Patrol: goal accepted!");
        };

        /* result callback */
        local_planner_options_.result_callback = [this](const LocalPlannerGoalHandler::WrappedResult &result)
        {
            status_promise_->set_value(result.code == rclcpp_action::ResultCode::SUCCEEDED
                                           ? BT::NodeStatus::SUCCESS
                                           : BT::NodeStatus::FAILURE);
        };

        /* send path */
        local_planner_client_->async_send_goal(goal_msg, local_planner_options_);

        /* optional: visualize the path */
#ifdef PATROL_PATH_VISUALIZATION
        nav_msgs::msg::Path patrol_path_msg;
        patrol_path_msg.header = goal_msg.path.header;
        patrol_path_msg.poses = goal_msg.path.poses;
        path_pub_->publish(patrol_path_msg);
#endif
    }

    void Patrol::verifyPathPoints(const std::vector<Position2D> &path_pts)
    {
        const auto &max_point_val = max_point_.value();
        const auto &min_point_val = min_point_.value();

        int valid_count = 0;
        for (const auto &pt : path_pts)
        {
            if (pt.x >= min_point_val.x && pt.x <= max_point_val.x &&
                pt.y >= min_point_val.y && pt.y <= max_point_val.y)
            {
                ++valid_count;
            }
        }

        if (valid_count < 20)
        {
            RCLCPP_WARN(this->node_->get_logger(), "Patrol: Valid path points less than 20, regenerate path!");
            throw std::runtime_error("Valid path points less than 20, need to regenerate.");
        }
    }

} // namespace aw_decision
