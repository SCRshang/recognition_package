#include <limits>

#include "aw_decision/nodes/judge_hp_and_ammo.hpp"

namespace aw_decision
{
    JudgeHPandAmmo::JudgeHPandAmmo(const std::string &name, const BT::NodeConfiguration &config)
        : BT::SimpleConditionNode(name, std::bind(&JudgeHPandAmmo::judgeHPandAmmo, this), config)
    {
    }

    BT::PortsList JudgeHPandAmmo::providedPorts()
    {
        return {BT::InputPort<bt_interfaces::msg::Common>("rmuc_common_msg", "{@rmuc_common_msg}", "rmuc_common message type port"),
                BT::InputPort<bt_interfaces::msg::RobotStatus>("rmuc_robot_status_msg", "{@rmuc_robot_status_msg}", "rmuc_robot_status message type port"),
                BT::InputPort<int>("hp_threshold", "{=}", "hp threshold"),
                BT::InputPort<int>("time_threshold", "{=}", "time threshold")};
    }

    BT::NodeStatus JudgeHPandAmmo::judgeHPandAmmo()
    {
        bool all_valid = true;
        rmuc_common_msg_ = getInput<bt_interfaces::msg::Common>("rmuc_common_msg");
        rmuc_robot_status_msg_ = getInput<bt_interfaces::msg::RobotStatus>("rmuc_robot_status_msg");
        hp_threshold_ = getInput<int>("hp_threshold");
        time_threshold_ = getInput<int>("time_threshold");
        if (!rmuc_common_msg_)
        {
            std::cerr << "JudgeStatus: Failed to get port of rmuc_common_msg!" << std::endl;
            all_valid = false;
        }
        if (!rmuc_robot_status_msg_)
        {
            std::cerr << "JudgeHPandAmmo: Failed to get port of rmuc_robot_status_msg!" << std::endl;
            all_valid = false;
        }
        if (!hp_threshold_)
        {
            std::cerr << "JudgeHPandAmmo: Failed to get port of hp_threshold!" << std::endl;
            all_valid = false;
        }
        if (!time_threshold_)
        {
            std::cerr << "JudgeHPandAmmo: Failed to get port of time_threshold!" << std::endl;
            all_valid = false;
        }
        if (!all_valid)
            return BT::NodeStatus::FAILURE;

        const auto &curr_hp = rmuc_robot_status_msg_->current_hp;
        const auto &curr_time = 420 - rmuc_common_msg_->stage_remain_time;
        const auto &hp_threshold_val = hp_threshold_.value();
        const auto &time_threshold_val = time_threshold_.value();
        bool is_in_range = false;

        if (curr_hp <= hp_threshold_val)
        {
            is_in_range = true;
        }
        if (curr_time == time_threshold_val)
        {
            is_in_range = true;
        }

        return is_in_range ? BT::NodeStatus::FAILURE : BT::NodeStatus::SUCCESS;
    }
} // namespace aw_decision